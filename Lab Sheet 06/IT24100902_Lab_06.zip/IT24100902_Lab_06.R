setwd("C:\\Users\\ASUS\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24100902")

#Exercise 

#1.1
#Binomial Distribution
#
1-pbinom(46,50,0.85,lower.tail=TRUE)

#2.1
#Number of customers call in an hour
#2.2
#Poisson Distribution
#2.3
dpois(15,12)