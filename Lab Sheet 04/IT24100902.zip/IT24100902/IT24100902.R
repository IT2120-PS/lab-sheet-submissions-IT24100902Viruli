setwd("C:\\Users\\IT24100902\\Desktop\\IT24100902")
#1
branch_data<-read.table("Exercise.txt",header= TRUE,sep = ",")
  

#2
str(branch_data)


#3
boxplot(branch_data$Sales_X1,main="Box plot for Sales",outline=TRUE,outpch=8,horizontal=TRUE,xlab="Sales")

#4
summary(branch_data$Advertising_X2)

IQR(branch_data$Advertising_X2)

#5
get.outliers<-function(X3){
  q1 <- quantile(X3)[2]
  q3 <- quantile(X3)[4]
  iqr<-q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("outliers:" ,paste(sort(X3[X3<lb | X3>ub]),collapse= "","")))
}

get.outliers(branch_data$Years_X3)